#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════╗
║                       TELEGRAM REPORTER                              ║
║                         smart-skidka.ru                              ║
╠══════════════════════════════════════════════════════════════════════╣
║  Telegram-бот для отправки отчётов оркестратора.                    ║
║  Поддерживает ежедневные отчёты, алерты, интерактивные команды    ║
║  и inline-кнопки для одобрения контента.                            ║
╚══════════════════════════════════════════════════════════════════════╝

Функционал:
    - Ежедневный отчёт в 9:00 (cron)
    - Алерты при ошибках агентов (мгновенно)
    - Команды: /start, /status, /agents, /report, /pause, /resume
    - Inline-кнопки для одобрения контента
    - Управление агентами через чат

Настройка:
    TELEGRAM_BOT_TOKEN=your_bot_token
    TELEGRAM_CHAT_ID=your_chat_id

Example:
    >>> reporter = TelegramReporter()
    >>> await reporter.send_daily_report(report_dict)
    >>> await reporter.send_alert("seo-agent", "Ошибка подключения к API")
    >>> await reporter.start_bot()  # Запуск long-polling для команд
"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timedelta
from typing import Any, Callable, Coroutine, Dict, List, Optional

import aiohttp
import structlog
from dotenv import load_dotenv

# ═══════════════════════════════════════════════════════════════════════════════
# Загрузка переменных окружения
# ═══════════════════════════════════════════════════════════════════════════════
load_dotenv()

# ═══════════════════════════════════════════════════════════════════════════════
# Настройка логирования
# ═══════════════════════════════════════════════════════════════════════════════
logger = structlog.get_logger("telegram_reporter")


# ═══════════════════════════════════════════════════════════════════════════════
# Константы
# ═══════════════════════════════════════════════════════════════════════════════
TELEGRAM_API_BASE: str = "https://api.telegram.org/bot{token}"
MAX_MESSAGE_LENGTH: int = 4096  # Максимальная длина сообщения Telegram
ALERT_COOLDOWN_SECONDS: int = 300  # Кулдаун между алертами одного агента


# ═══════════════════════════════════════════════════════════════════════════════
# Emoji-константы для отчётов
# ═══════════════════════════════════════════════════════════════════════════════
class Emoji:
    """Emoji для использования в отчётах."""
    OK = "✅"
    WARNING = "⚠️"
    ERROR = "❌"
    INFO = "ℹ️"
    CHART = "📊"
    CALENDAR = "📅"
    AGENT = "🤖"
    CLOCK = "⏱"
    LINK = "🔗"
    LIGHTNING = "⚡"
    FIRE = "🔥"
    ROCKET = "🚀"
    STAR = "⭐"
    BELL = "🔔"
    CHECK = "✓"
    CROSS = "✗"
    PAUSE = "⏸"
    PLAY = "▶"
    SETTINGS = "⚙️"
    MAGNIFIER = "🔍"
    SHOPPING = "🛒"
    TAG = "🏷"
    TREND_UP = "📈"
    TREND_DOWN = "📉"
    MONEY = "💰"
    TIME = "⏰"
    PERSON = "👤"
    GROUP = "👥"
    TARGET = "🎯"


# ═══════════════════════════════════════════════════════════════════════════════
# TelegramReporter — Класс для отправки отчётов
# ═══════════════════════════════════════════════════════════════════════════════
class TelegramReporter:
    """
    Репортёр в Telegram для оркестратора multi-agent системы.

    Отправляет различные типы сообщений:
    - Ежедневные отчёты с метриками
    - Алерты об ошибках агентов
    - Сводки по циклам
    - Управление через команды

    Attributes:
        bot_token: Токен Telegram бота
        chat_id: ID чата для отправки сообщений
        api_url: Базовый URL API Telegram
    """

    def __init__(
        self,
        bot_token: Optional[str] = None,
        chat_id: Optional[str] = None,
    ) -> None:
        """
        Инициализация репортёра.

        Args:
            bot_token: Токен Telegram бота (или TELEGRAM_BOT_TOKEN из env)
            chat_id: ID чата (или TELEGRAM_CHAT_ID из env)
        """
        self.bot_token: str = bot_token or os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.chat_id: str = str(chat_id or os.getenv("TELEGRAM_CHAT_ID", ""))
        self.api_url: str = TELEGRAM_API_BASE.format(token=self.bot_token)

        self._session: Optional[aiohttp.ClientSession] = None
        self._last_alert_time: Dict[str, datetime] = {}  # Кулдаун алертов
        self._paused_agents: set = set()  # Приостановленные агенты

        # Callback для управления агентами (устанавливается извне)
        self._pause_callback: Optional[Callable[[str], Coroutine[Any, Any, bool]]] = None
        self._resume_callback: Optional[Callable[[str], Coroutine[Any, Any, bool]]] = None

        if not self.bot_token or not self.chat_id:
            logger.warning(
                "TelegramReporter не полностью настроен. "
                "Проверьте TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID в .env"
            )
        else:
            logger.info(
                "TelegramReporter инициализирован",
                chat_id=self.chat_id,
            )

    # ─── Управление сессией ───────────────────────────────────────────────────

    async def _get_session(self) -> aiohttp.ClientSession:
        """Получает или создаёт HTTP-сессию."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={"Content-Type": "application/json"},
            )
        return self._session

    # ─── Базовые методы отправки ──────────────────────────────────────────────

    async def _api_request(
        self,
        method: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Выполняет запрос к API Telegram.

        Args:
            method: Название метода API (sendMessage, editMessageText и т.д.)
            payload: Параметры запроса

        Returns:
            Ответ от API Telegram
        """
        if not self.bot_token:
            logger.warning("Bot token не задан, запрос пропущен")
            return {"ok": False, "error": "No bot token"}

        url = f"{self.api_url}/{method}"
        session = await self._get_session()

        try:
            async with session.post(url, json=payload) as response:
                result = await response.json()
                if not result.get("ok"):
                    logger.warning(
                        "Ошибка API Telegram",
                        method=method,
                        error=result.get("description"),
                    )
                return result
        except Exception as e:
            logger.error("Исключение при запросе к Telegram API", method=method, error=str(e))
            return {"ok": False, "error": str(e)}

    async def _send_message(
        self,
        text: str,
        parse_mode: str = "Markdown",
        reply_markup: Optional[Dict[str, Any]] = None,
        chat_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Отправляет текстовое сообщение.

        Args:
            text: Текст сообщения
            parse_mode: Режим форматирования (Markdown, HTML)
            reply_markup: Inline-клавиатура
            chat_id: ID чата (переопределение)

        Returns:
            Ответ от API Telegram
        """
        target_chat = chat_id or self.chat_id

        # Разбиваем длинные сообщения
        if len(text) > MAX_MESSAGE_LENGTH:
            parts = []
            while text:
                if len(text) <= MAX_MESSAGE_LENGTH:
                    parts.append(text)
                    break
                # Ищём ближайший перенос строки
                split_at = text.rfind("\n", 0, MAX_MESSAGE_LENGTH)
                if split_at == -1:
                    split_at = MAX_MESSAGE_LENGTH
                parts.append(text[:split_at])
                text = text[split_at:].lstrip()

            results = []
            for part in parts:
                payload = {
                    "chat_id": target_chat,
                    "text": part,
                    "parse_mode": parse_mode,
                }
                if reply_markup:
                    payload["reply_markup"] = reply_markup
                result = await self._api_request("sendMessage", payload)
                results.append(result)
            return results[-1] if results else {"ok": False}

        payload = {
            "chat_id": target_chat,
            "text": text,
            "parse_mode": parse_mode,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup

        return await self._api_request("sendMessage", payload)

    # ─── Ежедневный отчёт ─────────────────────────────────────────────────────

    async def send_daily_report(self, report: Dict[str, Any]) -> bool:
        """
        Отправляет ежедневный отчёт в Telegram.

        Формирует красиво оформленный отчёт с метриками,
        статусами агентов и списком ошибок.

        Args:
            report: Словарь с данными отчёта:
                - date: Дата отчёта (YYYY-MM-DD)
                - total_agents: Всего агентов
                - successful_runs: Успешных запусков
                - failed_runs: Неудачных запусков
                - avg_validation_score: Средняя оценка валидации
                - agent_details: Список деталей по агентам
                - uptime_hours: Время работы
                - total_errors: Всего ошибок

        Returns:
            True если отправка успешна
        """
        date = report.get("date", datetime.now().strftime("%Y-%m-%d"))
        total = report.get("total_agents", 0)
        successful = report.get("successful_runs", 0)
        failed = report.get("failed_runs", 0)
        avg_score = report.get("avg_validation_score", 0.0)
        uptime = report.get("uptime_hours", 0)
        total_errors = report.get("total_errors", 0)

        # Определяем общий статус
        if failed == 0:
            status_emoji = Emoji.OK
            status_text = "Все системы работают нормально"
        elif failed < successful:
            status_emoji = Emoji.WARNING
            status_text = "Есть проблемы с некоторыми агентами"
        else:
            status_emoji = Emoji.ERROR
            status_text = "Требуется внимание — много ошибок"

        # Формируем сообщение
        message = (
            f"{Emoji.CHART} *Ежедневный отчёт оркестратора*\n"
            f"{Emoji.CALENDAR} Дата: `{date}`\n"
            f"{Emoji.CLOCK} Время работы: `{uptime:.1f} ч`\n\n"
            f"{status_emoji} *{status_text}*\n\n"
            f"{Emoji.SETTINGS} *Общая сводка:*\n"
            f"  {Emoji.AGENT} Всего агентов: `{total}`\n"
            f"  {Emoji.OK} Успешных запусков: `{successful}`\n"
            f"  {Emoji.ERROR} Неудачных: `{failed}`\n"
            f"  {Emoji.STAR} Средняя оценка: `{avg_score:.2f}`\n"
            f"  {Emoji.FIRE} Всего ошибок: `{total_errors}`\n\n"
            f"{Emoji.MAGNIIFIER} *Детали по агентам:*\n"
        )

        # Детали по каждому агенту
        for agent in report.get("agent_details", []):
            name = agent.get("name", "unknown")
            status = agent.get("status", "unknown")
            agent_score = agent.get("validation_score", 0.0)
            runs = agent.get("runs", 0)
            agent_failed = agent.get("failed", 0)

            if status == "success":
                emoji = Emoji.OK
            elif status == "failed":
                emoji = Emoji.ERROR
            else:
                emoji = Emoji.WARNING

            message += (
                f"{emoji} `{name}`\n"
                f"    Запусков: {runs} | Ошибок: {agent_failed}\n"
                f"    Оценка: {agent_score:.2f}\n"
            )

        # Ошибки
        errors = report.get("errors", [])
        if errors:
            message += f"\n{Emoji.BELL} *Ошибки (последние):*\n"
            for error in errors[:5]:
                message += f"  {Emoji.CROSS} `{error[:100]}`\n"

        # Добавляем inline-клавиатуру с действиями
        keyboard = {
            "inline_keyboard": [
                [
                    {"text": f"{Emoji.CHART} Полный отчёт", "callback_data": "report_full"},
                    {"text": f"{Emoji.SETTINGS} Статус агентов", "callback_data": "agents_status"},
                ],
                [
                    {"text": f"{Emoji.PAUSE} Пауза", "callback_data": "pause_menu"},
                    {"text": f"{Emoji.PLAY} Запуск", "callback_data": "resume_menu"},
                ],
            ]
        }

        result = await self._send_message(message, reply_markup=keyboard)
        success = result.get("ok", False)

        if success:
            logger.info("Ежедневный отчёт отправлен в Telegram")
        else:
            logger.error("Ошибка отправки ежедневного отчёта")

        return success

    # ─── Алерты ───────────────────────────────────────────────────────────────

    async def send_alert(self, agent_name: str, error: str) -> bool:
        """
        Отправляет алерт об ошибке агента.

        Реализует кулдаун: не отправляет повторные алерты
        одного агента чаще чем раз в 5 минут.

        Args:
            agent_name: Имя агента
            error: Текст ошибки

        Returns:
            True если алерт отправлен (или пропущен по кулдауну)
        """
        now = datetime.now()
        last_time = self._last_alert_time.get(agent_name)

        # Проверка кулдауна
        if last_time and (now - last_time).total_seconds() < ALERT_COOLDOWN_SECONDS:
            logger.debug(
                "Алерт пропущен по кулдауну",
                agent=agent_name,
                seconds_since_last=(now - last_time).total_seconds(),
            )
            return True  # Считаем успешным (не ошибка)

        self._last_alert_time[agent_name] = now

        # Формируем сообщение
        error_short = error[:300] if len(error) > 300 else error
        message = (
            f"{Emoji.BELL} *АЛЕРТ: Ошибка агента*\n\n"
            f"{Emoji.AGENT} Агент: `{agent_name}`\n"
            f"{Emoji.TIME} Время: `{now.strftime('%Y-%m-%d %H:%M:%S')}`\n\n"
            f"{Emoji.ERROR} *Ошибка:*\n"
            f"```\n{error_short}\n```"
        )

        # Inline-кнопки для действий
        keyboard = {
            "inline_keyboard": [
                [
                    {"text": f"{Emoji.PAUSE} Приостановить", "callback_data": f"pause:{agent_name}"},
                    {"text": f"{Emoji.PLAY} Перезапустить", "callback_data": f"restart:{agent_name}"},
                ],
                [
                    {"text": f"{Emoji.MAGNIIFIER} Логи", "callback_data": f"logs:{agent_name}"},
                    {"text": f"{Emoji.SETTINGS} Игнорировать", "callback_data": f"ignore:{agent_name}"},
                ],
            ]
        }

        result = await self._send_message(message, reply_markup=keyboard)
        success = result.get("ok", False)

        if success:
            logger.info("Алерт отправлен", agent=agent_name)
        else:
            logger.error("Ошибка отправки алерта", agent=agent_name)

        return success

    # ─── Сводка по циклу ──────────────────────────────────────────────────────

    async def send_summary(self, cycle_results: Dict[str, Any]) -> bool:
        """
        Отправляет сводку по циклу оркестратора.

        Args:
            cycle_results: Результаты цикла:
                - cycle_id: ID цикла
                - results: Список результатов по агентам
                - duration_ms: Длительность цикла
                - errors: Список ошибок

        Returns:
            True если отправка успешна
        """
        cycle_id = cycle_results.get("cycle_id", "unknown")
        results = cycle_results.get("results", [])
        duration_ms = cycle_results.get("duration_ms", 0)
        errors = cycle_results.get("errors", [])

        success_count = sum(1 for r in results if r.get("success"))
        fail_count = len(results) - success_count

        # Определяем статус цикла
        if fail_count == 0:
            header_emoji = Emoji.ROCKET
            header_text = "Все агенты отработали!"
        elif fail_count <= success_count // 2:
            header_emoji = Emoji.WARNING
            header_text = "Большинство агентов работают"
        else:
            header_emoji = Emoji.ERROR
            header_text = "Много ошибок — нужно вмешательство"

        # Конвертируем длительность в человеческий формат
        if duration_ms < 1000:
            duration_str = f"{duration_ms:.0f} мс"
        elif duration_ms < 60000:
            duration_str = f"{duration_ms/1000:.1f} сек"
        else:
            duration_str = f"{duration_ms/60000:.1f} мин"

        message = (
            f"{header_emoji} *{header_text}*\n"
            f"{Emoji.CALENDAR} Цикл: `{cycle_id[:20]}...`\n"
            f"{Emoji.CLOCK} Время работы: `{duration_str}`\n\n"
        )

        if success_count > 0:
            message += f"{Emoji.OK} *Успешно: {success_count} из {len(results)}*\n\n"

        # Человеческие описания агентов
        AGENT_DESCRIPTIONS = {
            "seo-agent": (Emoji.MAGNIIFIER, "SEO-оптимизация"),
            "smm-agent": (Emoji.FIRE, "SMM / Посты в соцсети"),
            "content-agent": (Emoji.STAR, "Генерация контента"),
            "performance-agent": (Emoji.TARGET, "Performance-маркетинг"),
            "analytics-agent": (Emoji.CHART, "Аналитика / Метрики"),
            "email-agent": (Emoji.PERSON, "Email-рассылки"),
            "trend-agent": (Emoji.TREND_UP, "Анализ трендов"),
        }

        # Сортируем: сначала ошибки, потом успешные
        sorted_results = sorted(results, key=lambda r: not r.get("success", True))

        for result in sorted_results:
            name = result.get("agent_name", "unknown")
            success = result.get("success", False)
            elapsed = result.get("elapsed_ms", 0)
            val_score = result.get("validation_score", 0.0)
            agent_result = result.get("result", {})

            # Получаем описание агента
            emoji, description = AGENT_DESCRIPTIONS.get(name, (Emoji.AGENT, name))
            status_icon = Emoji.OK if success else Emoji.ERROR

            # Время в секундах
            elapsed_sec = elapsed / 1000

            message += f"{status_icon} *{description}* (`{name}`)\n"
            message += f"   ⏱ {elapsed_sec:.1f} сек | 📊 качество: {val_score:.0%}\n"

            # Показываем что именно сделал агент (если есть данные)
            if isinstance(agent_result, dict):
                # Извлекаем конкретные результаты
                items = agent_result.get("items", agent_result.get("count", agent_result.get("generated", 0)))
                if items:
                    message += f"   📦 Создано/обработано: `{items}`\n"

                # Примеры результатов
                examples = agent_result.get("examples", agent_result.get("samples", []))
                if examples and isinstance(examples, list):
                    for ex in examples[:2]:
                        if isinstance(ex, str):
                            preview = ex[:60] + "..." if len(ex) > 60 else ex
                            message += f"   └─ {preview}\n"

                # URL или ссылки
                urls = agent_result.get("urls", agent_result.get("links", []))
                if urls and isinstance(urls, list):
                    for url in urls[:2]:
                        message += f"   🔗 {url}\n"

            message += "\n"

        # Ошибки цикла
        if errors:
            message += f"\n{Emoji.FIRE} *Ошибки:*\n"
            for error in errors[:3]:
                err_short = error[:200] if len(error) > 200 else error
                message += f"  {Emoji.CROSS} `{err_short}`\n"

        # Добавляем кнопки
        keyboard = {
            "inline_keyboard": [
                [
                    {"text": f"{Emoji.CHART} Детальный отчёт", "callback_data": "report_full"},
                    {"text": f"{Emoji.SETTINGS} Управление", "callback_data": "agents_status"},
                ],
            ]
        }

        result = await self._send_message(message, reply_markup=keyboard)
        return result.get("ok", False)

    # ─── Одобрение контента ───────────────────────────────────────────────────

    async def request_content_approval(
        self,
        content_type: str,
        content_preview: str,
        content_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Отправляет запрос на одобрение контента перед публикацией.

        Создаёт сообщение с inline-кнопками "Одобрить" и "Отклонить".

        Args:
            content_type: Тип контента (seo, smm, email, article)
            content_preview: Предпросмотр контента (первые 800 символов)
            content_id: Уникальный ID контента
            metadata: Дополнительные данные (автор, оценка и т.д.)

        Returns:
            True если запрос отправлен
        """
        meta = metadata or {}
        score = meta.get("validation_score", 0.0)
        author = meta.get("agent_name", "unknown")

        # Определяем emoji по типу контента
        type_emojis = {
            "seo": Emoji.MAGNIIFIER,
            "smm": Emoji.GROUP,
            "email": Emoji.BELL,
            "article": Emoji.CHART,
            "guide": Emoji.INFO,
        }
        type_emoji = type_emojis.get(content_type, Emoji.STAR)

        # Обрезаем превью
        preview = content_preview[:800] if len(content_preview) > 800 else content_preview

        message = (
            f"{Emoji.TARGET} *Запрос на одобрение контента*\n\n"
            f"{type_emoji} Тип: `{content_type.upper()}`\n"
            f"{Emoji.AGENT} Автор: `{author}`\n"
            f"{Emoji.STAR} Оценка: `{score:.2f}`\n"
            f"{Emoji.LINK} ID: `{content_id}`\n\n"
            f"{Emoji.INFO} *Предпросмотр:*\n"
            f"```\n{preview}\n```"
        )

        keyboard = {
            "inline_keyboard": [
                [
                    {"text": f"{Emoji.OK} Одобрить", "callback_data": f"approve:{content_id}"},
                    {"text": f"{Emoji.ERROR} Отклонить", "callback_data": f"reject:{content_id}"},
                ],
                [
                    {"text": f"{Emoji.PAUSE} Изменить", "callback_data": f"edit:{content_id}"},
                    {"text": f"{Emoji.SETTINGS} Детали", "callback_data": f"details:{content_id}"},
                ],
            ]
        }

        result = await self._send_message(message, reply_markup=keyboard)
        return result.get("ok", False)

    async def send_approval_result(
        self,
        content_id: str,
        approved: bool,
        moderator: str = "auto",
    ) -> bool:
        """
        Отправляет результат модерации контента.

        Args:
            content_id: ID контента
            approved: Одобрено ли
            moderator: Кто модерировал

        Returns:
            True если отправлено
        """
        emoji = Emoji.OK if approved else Emoji.ERROR
        action = "ОДОБРЕНО" if approved else "ОТКЛОНЕНО"

        message = (
            f"{emoji} *Контент {action}*\n\n"
            f"{Emoji.LINK} ID: `{content_id}`\n"
            f"{Emoji.PERSON} Модератор: `{moderator}`\n"
            f"{Emoji.TIME} Время: `{datetime.now().strftime('%H:%M:%S')}`"
        )

        result = await self._send_message(message)
        return result.get("ok", False)

    # ─── Команды бота ─────────────────────────────────────────────────────────

    async def handle_command(self, command: str, args: List[str]) -> str:
        """
        Обрабатывает команды Telegram.

        Поддерживаемые команды:
            /start — Приветственное сообщение
            /status — Общий статус оркестратора
            /agents — Список агентов и их статус
            /report — Полный отчёт
            /pause [agent] — Приостановить агента
            /resume [agent] — Возобновить агента
            /help — Справка по командам

        Args:
            command: Название команды (без /)
            args: Аргументы команды

        Returns:
            Текст ответа на команду
        """
        if command == "start":
            return (
                f"{Emoji.ROCKET} *Orchestrator Bot — smart-skidka.ru*\n\n"
                f"Привет! Я бот для управления multi-agent системой.\n\n"
                f"{Emoji.INFO} *Доступные команды:*\n"
                f"  `/status` — Статус оркестратора\n"
                f"  `/agents` — Список агентов\n"
                f"  `/report` — Полный отчёт\n"
                f"  `/pause [agent]` — Приостановить агента\n"
                f"  `/resume [agent]` — Возобновить агента\n"
                f"  `/help` — Справка"
            )

        elif command == "status":
            uptime = "N/A"  # Будет заполнено извне
            return (
                f"{Emoji.SETTINGS} *Статус оркестратора*\n\n"
                f"{Emoji.CLOCK} Время: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n"
                f"{Emoji.OK} Статус: `RUNNING`\n"
                f"{Emoji.AGENT} Агентов: запрашивается...\n"
                f"{Emoji.FIRE} Ошибок (за сегодня): запрашивается..."
            )

        elif command == "agents":
            return (
                f"{Emoji.AGENT} *Список агентов*\n\n"
                f"Используйте `/pause <agent>` и `/resume <agent>`\n"
                f"для управления агентами."
            )

        elif command == "report":
            return (
                f"{Emoji.CHART} *Запрос отчёта*\n\n"
                f"Ежедневный отчёт формируется автоматически в 9:00.\n"
                f"Последний отчёт будет отправлен ниже."
            )

        elif command == "pause":
            if not args:
                return (
                    f"{Emoji.ERROR} Укажите имя агента\n\n"
                    f"Пример: `/pause seo-agent`"
                )
            agent_name = args[0]
            if self._pause_callback:
                success = await self._pause_callback(agent_name)
                if success:
                    self._paused_agents.add(agent_name)
                    return f"{Emoji.PAUSE} Агент `{agent_name}` приостановлен"
                else:
                    return f"{Emoji.ERROR} Агент `{agent_name}` не найден"
            return f"{Emoji.ERROR} Callback не настроен"

        elif command == "resume":
            if not args:
                return (
                    f"{Emoji.ERROR} Укажите имя агента\n\n"
                    f"Пример: `/resume seo-agent`"
                )
            agent_name = args[0]
            if self._resume_callback:
                success = await self._resume_callback(agent_name)
                if success:
                    self._paused_agents.discard(agent_name)
                    return f"{Emoji.PLAY} Агент `{agent_name}` возобновлён"
                else:
                    return f"{Emoji.ERROR} Агент `{agent_name}` не найден или не приостановлен"
            return f"{Emoji.ERROR} Callback не настроен"

        elif command == "help":
            return (
                f"{Emoji.INFO} *Справка по командам*\n\n"
                f"*/start* — Начало работы с ботом\n"
                f"*/status* — Текущий статус оркестратора\n"
                f"*/agents* — Список всех агентов\n"
                f"*/report* — Запросить отчёт\n"
                f"*/pause [agent]* — Приостановить агента\n"
                f"*/resume [agent]* — Возобновить агента\n"
                f"*/help* — Эта справка\n\n"
                f"{Emoji.BELL} Алерты приходят автоматически при ошибках.\n"
                f"{Emoji.CALENDAR} Ежедневный отчёт в 9:00."
            )

        else:
            return f"{Emoji.ERROR} Неизвестная команда. Используйте /help"

    def set_pause_callback(
        self,
        callback: Callable[[str], Coroutine[Any, Any, bool]],
    ) -> None:
        """
        Устанавливает callback для приостановки агента.

        Args:
            callback: Асинхронная функция (agent_name) -> bool
        """
        self._pause_callback = callback

    def set_resume_callback(
        self,
        callback: Callable[[str], Coroutine[Any, Any, bool]],
    ) -> None:
        """
        Устанавливает callback для возобновления агента.

        Args:
            callback: Асинхронная функция (agent_name) -> bool
        """
        self._resume_callback = callback

    # ─── Long-polling для команд (опционально) ────────────────────────────────

    async def start_bot_polling(self, handle_update: Optional[Callable] = None) -> None:
        """
        Запускает long-polling для получения команд.

        Этот метод запускается в отдельной задаче и слушает
        обновления от Telegram.

        Args:
            handle_update: Функция обработки обновлений
        """
        if not self.bot_token:
            logger.warning("Bot token не задан, polling не запущен")
            return

        logger.info("Запуск Telegram bot polling")
        offset = 0

        while True:
            try:
                payload = {
                    "offset": offset,
                    "limit": 10,
                    "timeout": 30,
                }
                result = await self._api_request("getUpdates", payload)

                if result.get("ok") and result.get("result"):
                    for update in result["result"]:
                        offset = update["update_id"] + 1

                        # Обработка сообщений
                        if "message" in update and "text" in update["message"]:
                            text = update["message"]["text"]
                            chat_id = update["message"]["chat"]["id"]

                            if text.startswith("/"):
                                parts = text[1:].split()
                                command = parts[0]
                                args = parts[1:]

                                response = await self.handle_command(command, args)
                                await self._send_message(response, chat_id=str(chat_id))

                        # Обработка callback-запросов от inline-кнопок
                        if "callback_query" in update:
                            callback = update["callback_query"]
                            data = callback.get("data", "")
                            query_id = callback["id"]

                            # Подтверждаем обработку
                            await self._api_request(
                                "answerCallbackQuery",
                                {"callback_query_id": query_id, "text": "Обработано"},
                            )

                            # Обрабатываем действие
                            if data.startswith("pause:"):
                                agent = data.split(":", 1)[1]
                                if self._pause_callback:
                                    await self._pause_callback(agent)
                            elif data.startswith("resume:"):
                                agent = data.split(":", 1)[1]
                                if self._resume_callback:
                                    await self._resume_callback(agent)

                            if handle_update:
                                await handle_update(update)

            except asyncio.CancelledError:
                logger.info("Bot polling отменён")
                break
            except Exception as e:
                logger.error("Ошибка в polling", error=str(e))
                await asyncio.sleep(5)

    # ─── Закрытие ─────────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Закрывает HTTP-сессию."""
        if self._session and not self._session.closed:
            await self._session.close()
            logger.info("TelegramReporter сессия закрыта")


# ═══════════════════════════════════════════════════════════════════════════════
# Функции-обёртки для удобного использования
# ═══════════════════════════════════════════════════════════════════════════════
async def send_daily_report(report: Dict[str, Any]) -> bool:
    """
    Быстрая функция отправки ежедневного отчёта.

    Args:
        report: Данные отчёта

    Returns:
        True если отправлено
    """
    reporter = TelegramReporter()
    return await reporter.send_daily_report(report)


async def send_agent_alert(agent_name: str, error: str) -> bool:
    """
    Быстрая функция отправки алерта.

    Args:
        agent_name: Имя агента
        error: Текст ошибки

    Returns:
        True если отправлено
    """
    reporter = TelegramReporter()
    return await reporter.send_alert(agent_name, error)


async def request_approval(
    content_type: str,
    content_preview: str,
    content_id: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """
    Быстрая функция запроса одобрения контента.

    Args:
        content_type: Тип контента
        content_preview: Предпросмотр
        content_id: ID контента
        metadata: Доп. метаданные

    Returns:
        True если запрос отправлен
    """
    reporter = TelegramReporter()
    return await reporter.request_content_approval(
        content_type, content_preview, content_id, metadata
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Точка входа для тестирования
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    async def test():
        """Тестирование репортера."""
        reporter = TelegramReporter()

        # Проверка настроек
        if not reporter.bot_token:
            print("⚠️ TELEGRAM_BOT_TOKEN не задан в .env")
            print("Для теста создайте .env файл с TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID")
            return

        # Тест отправки сообщения
        test_message = (
            f"{Emoji.ROCKET} *Тест Telegram Reporter*\n\n"
            f"{Emoji.OK} Бот настроен и работает!\n"
            f"{Emoji.CLOCK} Время: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
        )

        result = await reporter._send_message(test_message)
        if result.get("ok"):
            print("✅ Тестовое сообщение отправлено!")
        else:
            print(f"❌ Ошибка: {result}")

        # Тест алерта
        await reporter.send_alert("test-agent", "Тестовая ошибка для проверки алертов")

        # Тест отчёта
        test_report = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "total_agents": 6,
            "successful_runs": 24,
            "failed_runs": 2,
            "avg_validation_score": 0.85,
            "agent_details": [
                {"name": "seo-agent", "status": "success", "validation_score": 0.92, "runs": 4, "failed": 0},
                {"name": "smm-agent", "status": "success", "validation_score": 0.88, "runs": 4, "failed": 0},
                {"name": "content-agent", "status": "warning", "validation_score": 0.72, "runs": 4, "failed": 1},
                {"name": "email-agent", "status": "success", "validation_score": 0.90, "runs": 4, "failed": 0},
                {"name": "performance-agent", "status": "failed", "validation_score": 0.45, "runs": 4, "failed": 1},
                {"name": "analytics-agent", "status": "success", "validation_score": 0.95, "runs": 4, "failed": 0},
            ],
            "uptime_hours": 12.5,
            "total_errors": 2,
        }
        await reporter.send_daily_report(test_report)

        # Тест запроса одобрения
        await reporter.request_content_approval(
            content_type="article",
            content_preview="Как выбрать лучший смартфон со скидкой в 2024 году. "
                           "В этом гайде мы рассмотрим топ-10 моделей...",
            content_id="article-001",
            metadata={"validation_score": 0.87, "agent_name": "content-agent"},
        )

        await reporter.close()

    # Запуск теста
    print("Запуск теста TelegramReporter...")
    print("Убедитесь, что TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID заданы в .env")
    asyncio.run(test())
