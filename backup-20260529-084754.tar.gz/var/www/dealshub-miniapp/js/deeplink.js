/* ============================================
   SmartSkidka.ru — Admitad Deeplink Generator
   ============================================ */

const ADMITAD_CONFIG = {
    publisherId: "2529186",
    // WW program (active)
    ww: { offerId: "6115", adspaceId: "2939190" },
    // RU&CIS program (awaiting moderation — switch after approval)
    rucis: { offerId: "25179", adspaceId: "2940069" },
    // Default: use WW until RU&CIS approved
    activeProgram: "rucis"
};

/**
 * Генерирует Admitad deeplink из AliExpress URL.
 * @param {string} aliUrl — оригинальный URL товара или поиска
 * @param {string} subId — опциональный sub-id для трекинга (например, категория)
 * @returns {string} Admitad deeplink
 */
function generateAdmitadDeeplink(aliUrl, subId = "") {
    if (!aliUrl) return '#';
    
    const prog = ADMITAD_CONFIG[ADMITAD_CONFIG.activeProgram];
    const encodedUrl = encodeURIComponent(aliUrl);
    let deeplink = `https://ad.admitad.com/g/${prog.offerId}/${ADMITAD_CONFIG.publisherId}/${prog.adspaceId}/?ulp=${encodedUrl}`;
    
    if (subId) {
        deeplink += "&subid=" + encodeURIComponent(subId);
    }
    
    return deeplink;
}

/**
 * Генерирует deeplink из itemId (чистый AliExpress item URL).
 * @param {string} itemId — ID товара на AliExpress (например, "1005010743227033")
 * @param {string} subId — опциональный sub-id
 * @returns {string} Admitad deeplink
 */
function generateDeeplink(itemId, subId = "") {
    if (!itemId) return '#';
    
    const aliUrl = `https://www.aliexpress.com/item/${itemId}.html`;
    return generateAdmitadDeeplink(aliUrl, subId);
}

/**
 * Генерирует поисковый deeplink.
 * @param {string} searchQuery — поисковый запрос
 * @param {string} subId — опциональный sub-id
 * @returns {string} Admitad deeplink на поиск
 */
function generateSearchDeeplink(searchQuery, subId = "") {
    if (!searchQuery) return '#';
    
    const aliUrl = `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(searchQuery)}`;
    return generateAdmitadDeeplink(aliUrl, subId);
}

/**
 * Проверяет, является ли URL уже Admitad deeplink'ом (любого формата).
 * @param {string} url
 * @returns {boolean}
 */
function isAdmitadDeeplink(url) {
    if (!url) return false;
    return url.includes('ad.admitad.com') || 
           url.includes('rzekl.com') || 
           url.includes('s.click.aliexpress.com');
}

/**
 * Извлекает itemId из AliExpress URL или deeplink'а.
 * @param {string} url
 * @returns {string|null}
 */
function extractItemId(url) {
    if (!url) return null;
    
    // Прямой AliExpress URL: /item/XXXX.html
    let match = url.match(/item\/(\d+)\.html/);
    if (match) return match[1];
    
    // Из URL-encoded deeplink
    match = url.match(/item%2F(\d+)/);
    if (match) return match[1];
    
    // Из double-encoded
    match = url.match(/item%252F(\d+)/);
    if (match) return match[1];
    
    return null;
}

/**
 * Переключает активную программу Admitad (ww / rucis).
 * @param {string} program — "ww" или "rucis"
 */
function setAdmitadProgram(program) {
    if (ADMITAD_CONFIG[program]) {
        ADMITAD_CONFIG.activeProgram = program;
        console.log(`[Deeplink] Программа переключена на: ${program}`);
    } else {
        console.error(`[Deeplink] Неизвестная программа: ${program}`);
    }
}

/**
 * Автоматически конвертирует все aliLink в PRODUCTS_DB в Admitad deeplink'и.
 * ВСЕГДА перезаписывает ссылки в актуальный формат ad.admitad.com.
 * Использует itemId если доступен, иначе извлекает из aliLink.
 * Call once after page load or before rendering.
 */
function convertAllLinksToDeeplinks() {
    if (typeof PRODUCTS_DB === 'undefined') {
        console.warn('[Deeplink] PRODUCTS_DB не найден — пропускаю конвертацию');
        return;
    }
    
    let converted = 0;
    let skipped = 0;
    
    PRODUCTS_DB.forEach(product => {
        // Приоритет: itemId > extract from aliLink > aliLink as-is
        let itemId = product.itemId;
        if (!itemId && product.aliLink) {
            itemId = extractItemId(product.aliLink);
        }
        
        if (itemId) {
            product.aliLink = generateDeeplink(itemId, product.category);
            converted++;
        } else if (product.aliLink) {
            // Fallback: оборачиваем оригинальный URL
            product.aliLink = generateAdmitadDeeplink(product.aliLink, product.category);
            converted++;
        } else {
            skipped++;
        }
    });
    
    console.log(`[Deeplink] Конвертировано: ${converted}, пропущено: ${skipped}`);
}

/**
 * Оборачивает все ссылки на странице в Admitad deeplink'и.
 * Полезно для динамически добавляемого контента.
 */
function wrapPageLinks() {
    document.querySelectorAll('a[href*="aliexpress.com/item/"]').forEach(link => {
        if (!isAdmitadDeeplink(link.href)) {
            const itemId = extractItemId(link.href);
            if (itemId) {
                link.href = generateDeeplink(itemId);
            }
        }
    });
}

// Экспорт для разных сред
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ADMITAD_CONFIG,
        generateAdmitadDeeplink,
        generateDeeplink,
        generateSearchDeeplink,
        isAdmitadDeeplink,
        extractItemId,
        setAdmitadProgram,
        convertAllLinksToDeeplinks,
        wrapPageLinks
    };
}
