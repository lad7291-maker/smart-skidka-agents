/* ============================================
   SmartSkidka.ru — Products Loader (Lazy)
   ============================================ */

const PRODUCTS_BASE = 'products/';

let _loadedCategories = new Set();
let _products = [];
let _allLoaded = false;

// Use inline PRODUCTS_DB immediately (loaded before this script)
console.log('[Products] typeof PRODUCTS_DB:', typeof PRODUCTS_DB);
console.log('[Products] PRODUCTS_DB length:', typeof PRODUCTS_DB !== 'undefined' ? PRODUCTS_DB.length : 'N/A');
if (typeof PRODUCTS_DB !== 'undefined' && Array.isArray(PRODUCTS_DB) && PRODUCTS_DB.length > 0) {
    _products = PRODUCTS_DB;
    window.PRODUCTS_DB = _products;
    console.log('[Products] Using inline PRODUCTS_DB: ' + _products.length + ' items');
} else {
    console.log('[Products] PRODUCTS_DB not available!');
}

/**
 * Загружает стартовый набор (24 товара) для мгновенного рендера.
 */
async function loadInitialProducts() {
    if (_products.length > 0) return _products;
    try {
        // Cache-bust: always fetch fresh data
        const cacheBuster = '?v=' + Date.now();
        const res = await fetch(PRODUCTS_BASE + 'all.json' + cacheBuster, { cache: 'no-store' });
        if (!res.ok) throw new Error('all.json failed: ' + res.status);
        _products = await res.json();
        window.PRODUCTS_DB = _products; // для обратной совместимости
        console.log('[Products] Initial load: ' + _products.length + ' items');
        return _products;
    } catch (e) {
        console.error('[Products] Failed to load all.json:', e);
        // Fallback: use inline PRODUCTS_DB if available
        if (typeof PRODUCTS_DB !== 'undefined' && Array.isArray(PRODUCTS_DB) && PRODUCTS_DB.length > 0) {
            _products = PRODUCTS_DB;
            window.PRODUCTS_DB = _products;
            console.log('[Products] Fallback to inline PRODUCTS_DB: ' + _products.length + ' items');
            return _products;
        }
        window.PRODUCTS_DB = [];
        return [];
    }
}

/**
 * Загружает категорию по требованию (лениво).
 * @param {string} category — 'electronics', 'auto', 'clothing', ...
 */
async function loadCategory(category) {
    if (_loadedCategories.has(category)) return _products;
    try {
        const cacheBuster = '?v=' + Date.now();
        const res = await fetch(PRODUCTS_BASE + category + '.json' + cacheBuster, { cache: 'no-store' });
        if (!res.ok) {
            console.warn('[Products] Category not found: ' + category);
            return _products;
        }
        const items = await res.json();
        // Удаляем старые товары этой категории (если были) и добавляем новые
        _products = _products.filter(p => p.category !== category);
        _products.push(...items);
        _loadedCategories.add(category);
        window.PRODUCTS_DB = _products;
        console.log('[Products] Loaded ' + category + ': ' + items.length + ' items');
        return _products;
    } catch (e) {
        console.error('[Products] Failed to load ' + category + ':', e);
        return _products;
    }
}

/**
 * Загружает все категории (для поиска или «Все»).
 */
async function loadAllProducts() {
    if (_allLoaded) return _products;
    const categories = ['auto','beauty','clothing','electronics','home','jewelry','sports','toys'];
    await Promise.all(categories.map(c => loadCategory(c)));
    _allLoaded = true;
    console.log('[Products] All loaded: ' + _products.length + ' items');
    return _products;
}

/**
 * Получить товар по ID (из уже загруженных).
 */
function getProductById(id) {
    return _products.find(p => p.id === id);
}

/**
 * Получить товары по категории (загружает если нужно).
 */
async function getProductsByCategory(category) {
    if (category === 'all') {
        await loadAllProducts();
        return _products;
    }
    await loadCategory(category);
    return _products.filter(p => p.category === category);
}

/**
 * Синхронная версия getProductsByCategory (для обратной совместимости).
 * Возвращает уже загруженные товары.
 */
function getProductsByCategorySync(category) {
    console.log('[getProductsByCategorySync] _products length:', _products.length, 'category:', category);
    if (category === 'all') return _products;
    return _products.filter(p => p.category === category);
}

// Экспорт глобальных функций (app.js ожидает их)
window.getProductById = getProductById;
window.getProductsByCategory = getProductsByCategorySync;

// Auto-init: загрузить стартовый набор при подключении скрипта
if (typeof document !== 'undefined') {
    loadInitialProducts();
}

// Экспорт для модульных сред
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        loadInitialProducts,
        loadCategory,
        loadAllProducts,
        getProductById,
        getProductsByCategory,
        getProductsByCategorySync
    };
}
