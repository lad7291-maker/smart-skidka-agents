/* ============================================
   SmartSkidka.ru — Service Worker
   ============================================ */

const CACHE_NAME = 'smartskidka-v3'; // bump to invalidate old cache
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/css/style.css',
    '/js/products-loader.js',
    '/js/app.js',
    '/js/deeplink.js',
    '/manifest.json'
];

const ICON_ASSETS = [
    '/icons/icon-72x72.png',
    '/icons/icon-96x96.png',
    '/icons/icon-128x128.png',
    '/icons/icon-144x144.png',
    '/icons/icon-152x152.png',
    '/icons/icon-192x192.png',
    '/icons/icon-384x384.png',
    '/icons/icon-512x512.png'
];

const ALL_CACHE_ASSETS = [...STATIC_ASSETS, ...ICON_ASSETS];

// Install — cache static assets
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(ALL_CACHE_ASSETS))
            .then(() => self.skipWaiting())
    );
});

// Activate — clean old caches
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(name => name !== CACHE_NAME)
                        .map(name => caches.delete(name))
                );
            })
            .then(() => self.clients.claim())
    );
});

// Fetch — cache-first strategy for static, network-first for images
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET requests
    if (request.method !== 'GET') return;

    // For JSON data (products) — always fetch fresh, cache as fallback
    if (url.pathname.startsWith('/products/')) {
        event.respondWith(
            fetch(request)
                .then(response => {
                    if (response.status === 200) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
                    }
                    return response;
                })
                .catch(() => caches.match(request))
        );
        return;
    }
    if (url.origin !== self.location.origin) {
        // Cache images from Unsplash
        if (request.destination === 'image') {
            event.respondWith(cacheImage(request));
        }
        return;
    }

    event.respondWith(
        caches.match(request)
            .then(cached => {
                // For HTML/JS/CSS — return cached immediately, update in background
                if (cached) {
                    // Revalidate in background
                    fetch(request).then(response => {
                        if (response && response.status === 200) {
                            caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
                        }
                    }).catch(() => {});
                    return cached;
                }

                return fetch(request)
                    .then(response => {
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }
                        const responseToCache = response.clone();
                        caches.open(CACHE_NAME).then(cache => {
                            cache.put(request, responseToCache);
                        });
                        return response;
                    })
                    .catch(() => {
                        if (request.mode === 'navigate') {
                            return caches.match('/');
                        }
                        return new Response('', { status: 503, statusText: 'Service Unavailable' });
                    });
            })
    );
});

// Cache images from external sources
async function cacheImage(request) {
    const cache = await caches.open(CACHE_NAME + '-images');
    const cached = await cache.match(request);
    if (cached) return cached;

    try {
        const response = await fetch(request);
        if (response && response.status === 200) {
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        // Return placeholder for failed image loads
        return new Response('', { status: 404 });
    }
}

// Background sync for cart updates
self.addEventListener('sync', (event) => {
    if (event.tag === 'sync-cart') {
        event.waitUntil(syncCart());
    }
});

async function syncCart() {
    // Cart data is already in localStorage, but we could sync with server here
    const clients = await self.clients.matchAll();
    clients.forEach(client => client.postMessage({ type: 'CART_SYNCED' }));
}

// Push notifications support
self.addEventListener('push', (event) => {
    const data = event.data?.json() || {
        title: 'SmartSkidka',
        body: 'Новые скидки уже здесь!',
        icon: '/icons/icon-192x192.png',
        badge: '/icons/icon-72x72.png'
    };

    event.waitUntil(
        self.registration.showNotification(data.title, {
            body: data.body,
            icon: data.icon,
            badge: data.badge,
            tag: 'smartskidka-notification',
            requireInteraction: false,
            data: data.url || '/'
        })
    );
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil(
        clients.openWindow(event.notification.data || '/')
    );
});

// Message from main thread
self.addEventListener('message', (event) => {
    if (event.data === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});
